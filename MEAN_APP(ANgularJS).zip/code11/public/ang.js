var app = angular.module('myapp', ['ngRoute']);

app.run(function($rootScope){
 //   $rootScope.session_key = ;
})

app.config(function($routeProvider) {
   $routeProvider.when('/', {
       templateUrl : 'views/home.html',
       controller : 'authController'
   })
   .when('/welcome', {
       templateUrl : 'views/welcome.html',
       controller : 'authController',
    //     resolve: {
    //         message: function(messageService){
    //             return messageService.getMessage();
    //     }
    // }
    
   })
   .when('/login',{
       templateUrl:'views/login.html',
       controller:'authController'
   })
   .when('/addtrainee',{
       templateUrl:'views/addtrainee.html',
       controller:'authController'
   })
   .when('/monitortrainee',{
       templateUrl: 'views/monitortrainee.html',
       controller:'authController'
   });
});


app.directive('myFirstDir',['$http',function($http){
  return {
  restrict : 'E',
  replace:true,
//    scope:{
//       // trainee : '&',
//        items :'=',
//        model : '=',
//        selectedItem : '='
//        //trainee : '&'
//    },
//    template:'<div></div>',
//   template:'<div class="my-first-dir">'+ 
  //template:'<select ng-model="selectedItem" ng-options="i.username for i in items" ng-click="trainee()">',
//   '</div>',
  link:function($scope, element, attrs) {
     $scope.trainee = function() {
     $http.get('/traineedata').then(function(res){ 
     $scope.result=res.data;
       });
     }
        }
  };
}]);

app.service("githubService", function($http, $q) {

  var deferred = $q.defer();

  this.getAccount = function() {
    return $http.get('/checkAuth')
      .then(function(response) {
          console.log(response.data);
          return response.data;
      });
  };
});


app.controller('authController',function($scope, $rootScope, $location, $http,$q, githubService) {
 
 var app = this;



githubService.getAccount().then(function(result) {
          //console.log(result.result);
        app.status = result.result;
console.log(app.status);
       
      },
      function(error) {
        
      }
    );

//console.log(app.status);

$scope.loadAuthPage = function(flag) {
      switch(flag) {
            case 'login':
                $location.path('/login');
            break;
              }
    };

    $scope.login = function(){
        githubService.getAccount().then (function(response){
            
    $http.post('/login',$scope.tr).then(function(data){
        console.log(data.data);
         console.log(data.data.result);
   
        if(data.data.result== true){
            console.log("from ang.js");
            $location.path('/welcome');
        }
        else{
            $location.path('/login');
        }

});
        });
};


$scope.addtrainee = function(){

    githubService.getAccount().then (function(response){
    console.log(response.result);
    if(response.result){
        
     console.log("resp.result is true");
     $location.path('/addtrainee');
    } else { 
        
        $location.path('/login');
    }
});
}
    
    $scope.addtodb = function(){
githubService.getAccount().then (function(response){
    if(response.result){
        var selectId = document.getElementById('selectedbatch');
    //var selectedbatch = selectId.options[selectId.selectedIndex].value;
    console.log(selectedbatch);
    console.log("entering into db");
$http.post('http://localhost:3307/saved',$scope.user).then(function(req,res)
   {
    res.data=$scope.user;
    });
    }
    else   {
            $location.path('/login');
           }
    });


    };









// $scope.addtrainee = function(){
  
//     githubService.getAccount().then (function(response){
//     console.log(response.result);
//     if(response.result){
        
//     $scope.addtodb = function(){

// var selectId = document.getElementById('selectedbatch');
//     //var selectedbatch = selectId.options[selectId.selectedIndex].value;
//     console.log(selectedbatch);
//     console.log("entering into db");
// $http.post('http://localhost:3307/saved',$scope.user).then(function(req,res){
// res.data=$scope.user;
// });
// };
//     }
//     else{
//         $location.path('/login');
//     }

//     });

    
// }
    


$scope.back = function(){
  $location.path('/welcome');
};
$scope.logout = function(){
    console.log("entered into logout fn");
    $http.post('/logout_session');
  $location.path('/login');
};
$scope.monitortrainee = function(){
    $location.path('/monitortrainee');
}

        
    });
















   // $scope.ItemList = [{"name":"kal","id":123},{"name":"abc","id":173}];

//     function trainee($scope){
//         console.log("hello");
//     $http.get('/traineedata').then(function(res){ 
//   $scope.result=res.data;
//   console.log($scope.result);
//     });
// }

//    $scope.sessioncheck = function(){
//        $http.post('/session_check',$rootScope.test).then(function(data){

//        });
//    };

//     $scope.loadAuthPage = function(flag) {
//       switch(flag) {
//             case 'login':
//                 $location.path('/login');
//             break;
//       }
//     };
// $scope.login = function(){
//     $http.post('/login',$scope.tr).then(function(data){
//         console.log(data.data);
//          console.log(data.data.sessiondata);
//         if(data.data.result == true){
//             console.log("from ang.js");
//             $location.path('/welcome');
//         }
//         else{
//             $location.path('/login');
//         }

// });
// };


// $scope.addtrainee = function(){
// $location.path('/addtrainee');
// };
// /// to send data to db and add it
// $scope.addtodb = function(){
// var selectId = document.getElementById('selectedbatch');
//     //var selectedbatch = selectId.options[selectId.selectedIndex].value;
//     console.log(selectedbatch);
//     console.log("entering into db");
// $http.post('http://localhost:3307/saved',$scope.user).then(function(req,res){
// res.data=$scope.user;
// });
// };


// $scope.back = function(){
//   $location.path('/welcome');
// };
// $scope.logout = function(){
//   $location.path('/login');
// };
// $scope.monitortrainee = function(){
//     $location.path('/monitortrainee');
// }
// });

//getting data from mongo
// $scope.trainee = function(){
//     $http.get('/traineedata').then(function(res){
//         console.log("hello");
//   $scope.result=res.data;
//     });
// }

