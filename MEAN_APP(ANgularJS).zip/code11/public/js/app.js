var app = angular.module('myapp', []);

app.config(function($routeProvider) {
   $routeProvider.when('/profile', {
       templateUrl:'profile.html',
       controller:'profileController',
       resolve:function() {
           
       }
   });
});

app.factory('authService', function($q, $http) {
    return {
        'authenticate':function() {
            //
            $http.get()
        }
    };
});

app.controller('mycntrl', function($scope, $http) {
    $http.get('http://localhost:8081/getData').then(function(res) {
        $scope.users = res.data;
    },
    function(err) {
        
    });
});